// Simple interactivity: hamburger toggle + navigation between pages
const hamburger = document.getElementById('hamburger');
const nav = document.getElementById('nav');
const links = Array.from(document.querySelectorAll('.nav-link'));
const pages = Array.from(document.querySelectorAll('.page'));

function closeNav(){
  nav.classList.remove('show');
  nav.setAttribute('aria-hidden','true');
}

function openNav(){
  nav.classList.add('show');
  nav.setAttribute('aria-hidden','false');
}

hamburger && hamburger.addEventListener('click', () => {
  if(nav.classList.contains('show')) closeNav();
  else openNav();
});

links.forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    const target = link.getAttribute('data-page');
    pages.forEach(p => p.classList.remove('active'));
    const el = document.getElementById(target);
    if(el) el.classList.add('active');
    closeNav();
  });
});

// close nav when clicking outside (mobile)
document.addEventListener('click', (e) => {
  if(!nav.contains(e.target) && !hamburger.contains(e.target)){
    closeNav();
  }
});

const ctx = document.getElementById("attendanceChart").getContext("2d");

new Chart(ctx, {
  type: 'doughnut',
  data: {
    labels: ['Catur', 'honor of kings', 'Mobile legends', 'Free fire'],
    datasets: [{
      data: [3, 1, 5, 7],
      backgroundColor: ['#1e7b6f', '#ffb300', '#f44336', "#29b6f6"]
    }]
  },
  options: {
    plugins: {
      datalabels: {
        color: '#fff',
        formatter: (value, ctx) => {
          let total = ctx.chart.data.datasets[0].data.reduce((a, b) => a + b, 0);
          let percentage = ((value / total) * 100).toFixed(1) + "%";
          return percentage;
        },
        font: {
          weight: 'bold',
          size: 14
        }
      }
    }
  },
  plugins: [ChartDataLabels]
});
const searchInput = document.getElementById("searchInput");
const studentList = document.getElementById("studentList");
const students = studentList.getElementsByTagName("li");
const noResult = document.getElementById("noResult");

searchInput.addEventListener("keyup", function () {
  const filter = searchInput.value.toLowerCase();
  let found = false;

  for (let i = 0; i < students.length; i++) {
    const name = students[i].textContent.toLowerCase();
    if (name.includes(filter)) {
      students[i].style.display = "";
      found = true;
    } else {
      students[i].style.display = "none";
    }
  }

  // kalau gak ada yang cocok
  if (!found) {
    noResult.style.display = "block";
  } else {
    noResult.style.display = "none";
  }
});
