README - Template Minimal Kelas
---------------------------------
Folder structure:
- index.html
- style.css
- script.js
- /images
    - hero-placeholder.svg       (besar, untuk banner/hero)
    - avatar-placeholder.svg     (ikon kecil untuk daftar siswa)
    - teacher-placeholder.svg    (foto wali kelas)

Cara pakai:
1. Download dan ekstrak zip.
2. Ganti file di folder `images` dengan gambar yang lo punya (jaga nama file kalau mau langsung pakai).
   - Atau ubah path di index.html ke nama file baru.
3. Buka index.html di browser (double-click) untuk melihat hasil.
4. Mau ditambah fitur? bilang aja: grafik kehadiran, dark mode, export CSV, dll.

Notes:
- Template ini minimal dan responsif. Ganti warna di style.css :root untuk skema warna lain.
- Kalau mau gue gabungkan gambar yang nanti lo kirim, upload gambar dan gue bisa update versi zip lagi.
